/*
File............: javascript.js
Author..........: (C) GeNeura Team, 2000
                  V�ctor MAnuel Rivas Santos: vrivas@ujaen.es
Date............: 27-Jun-2000
Description.....: Fichero con funciones y procedimientos en javascript para
                  el curso de Javascript que doy con JJ. 
                  Segunda versi�n del Cursillo
Modifications...:
============ 1 ============
  Auhtor........:
  Date..........:
  Description...:
*/

var cuenta_secciones=1;
var cuenta_ejemplos=0;
var LA_SESION;

/*function pinta_seccion() {
  var d=document;
  d.writeln( "<FORM>" );
  d.writeln( "Secciones: <SELECT NAME=seccion_"+this.id+">" );
  d.writeln( "<OPTION SELECTED=true VALUE=",this.url,">",this.id,".",
		this.nombre,"</OPTION>" );
  this.sub.pinta();
  d.writeln( "</SELECT>" );
  d.writeln( "</FORM>" );
}
*/
/*
function pinta_seccion() {
  var d=document;
  d.writeln( "<P><DIV><FONT SIZE=+1><B>"+this.id+". "+this.nombre+"</B></FONT> <BR>" );
  this.sub.pinta();
  d.writeln( "</DIV><DIV ALIGN='right'>" );
  if( this.id>1 ) {
    secciones[this.id-1].enlace( "Anterior:" );
    if ( this.id<secciones.length ) {
      d.writeln( " " );
    }
  }

  if ( this.id<secciones.length-1 ) {
    secciones[this.id+1].enlace( "Siguiente:" );
  }

  d.writeln( "</DIV></P>" );
}
*/

function pinta_seccion() {
  var d=document;
  d.writeln( "<P><DIV><FONT SIZE=+1><B>"+this.id+". "+this.nombre+"</B></FONT> <BR>" );
  this.sub.pinta();
  d.writeln( "</DIV><DIV ALIGN='right'>" );
  for( var i=0; i<secciones.length-1; ++i ) {
    if ( i>0 && i<secciones.length-1 ) { d.writeln( " - " ); }
    if( this.id==i+1 ) {
       d.writeln( "<B>"+this.nombre+"</B>" );
    } else {
      d.writeln( "<FONT SIZE=-2>" );
      secciones[i+1].enlace("");
      d.writeln( "</FONT>" );
    }
  }
  d.writeln( "</DIV></P>" );

}

function enlace_seccion( cad ) {
  var d=document;
  d.writeln( "<FONT SIZE=-1 COLOR=black>",cad,"</FONT>" );
  d.writeln( " <A HREF='"+this.url+"'>"+this.nombre+"</A>" );
}

function Seccion( nombre, url, sub ) {
  this.id=cuenta_secciones;
  cuenta_secciones++;
  this.nombre=nombre;
  this.url=url;
  this.sub=sub;
  
  this.pinta=pinta_seccion;
  this.enlace=enlace_seccion;

  this.sub.alter( this.id );
}

/*
-----------------------------------------------------------
 OBJETO:                        SUBSECCION
-----------------------------------------------------------
*/

/*
========================
PINTA_SUBSECCION( )
========================
*/
function pinta_subseccion() {
  var d=document;
  d.writeln( "<A HREF='#"+this.ancla+"'><FONT SIZE=-1>"+
	     this.nombre+"</FONT></A>" );
}
/*
========================
ALTER_SUBSECCION( num )
Modifica el identificador poni�ndole un num*SESION_MULTIPLIER delante
========================
*/

function alter_subseccion( num ) {
  this.id=num+"."+this.id;
}

/*
========================
SUBSECCION( nombre, ancla, id )
Constructor de subseccion
=======================
*/
function subseccion( nombre, ancla, id ) {
  this.id=id+1;
  this.nombre=nombre; 
  this.ancla=ancla;
  this.alter=alter_subseccion;
  this.pinta=pinta_subseccion;
}


/*
-----------------------------------------------------------
 OBJETO:                        MANY_SUBSECCION
-----------------------------------------------------------
*/
/*
=================
PINTA_MANY_SUBSECCION
Pinta la subseccion
=================
*/
function pinta_many_subseccion() {
  for( var i=0; i<this.mat.length; ++i ) {
    this.mat[i].pinta();
    if ( i<this.mat.length-1 ) {
     document.writeln( " - " );
    }
  }
}

/*
=================
ADD_SUBSECCION( nombre, ancla )
A�ade una subseccion
=================
*/

function add_subseccion( nombre, ancla ) {
  this.mat[this.mat.length]=new subseccion( nombre, ancla, this.mat.length );  
}

/*
=================
ALTER_MANY_SUBSECCION( num )
Modifica todas las subsecciones incluidas en tes MANY_SUBSESION a�adi�ndoles
el identificador de la sesion en que est�n
=================
*/
function alter_many_subseccion( num ) {
  for( var i=0; i<this.mat.length; ++i ) {
    this.mat[i].alter( num );
  }
}

/*
=================
MANY_SUBSECCION()
Constructor
=================
*/
function many_subseccion() {
  this.mat=new Array;
  this.add=add_subseccion;
  this.alter=alter_many_subseccion;
  this.pinta=pinta_many_subseccion;
}


/*
-----------------------------------------------------------
                 INICIALIZACION DE SESIONES Y SUBSECCIONES
-----------------------------------------------------------
*/
var secciones=new Array;
function inicializa() {
  var c=1;
  { // Introduccion
    sub=new many_subseccion;
    sub.add( "Qu� es Javascript","que_es" );
    sub.add( "Qu� es NO Javascript","que_no_es" );
    sub.add( "Configuraci�n del entorno","configurar_entorno" );
    //sub.add( "Diferencias Javascript-Java","diferencias" );
    secciones[c++]=new Seccion( "Introducci�n", "js_intro.html", sub );
  }
  { //  Sintaxis I
    sub=new many_subseccion;
    sub.add( "Filosof�a general","filosofia" );
    sub.add( "Variables","variables" );
    sub.add( "Sentencias","sentencias" );
    secciones[c++]=new Seccion( "Sintaxis I", "js_sintaxis_I.html", sub );
  }
  { //  C�digo Javascript en HTML
    sub=new many_subseccion;
    sub.add( "Tags","tag" );
    sub.add( "Ficheros Externos","ficheros" );
    sub.add( "Eventos","eventos" );
    secciones[c++]=new Seccion( "Uso", "js_uso.html", sub );
  }
  { //  Sintaxis II
    sub=new many_subseccion;
    sub.add( "Funciones","funciones" );
    sub.add( "Matrices","matrices" );
    sub.add( "Objetos","objetos" );
    sub.add( "JSON","json" );
    secciones[c++]=new Seccion( "Sintaxis II", "js_sintaxis_II.html", sub );

  }
  { //  Objetos de la Ventana
    sub=new many_subseccion;
    sub.add( "Introducci�n","introduccion" );
    sub.add( "Window","window" );
    sub.add( "Navigator","navigator" );
    sub.add( "Frames","frames" );
    sub.add( "Referenciar","referenciar" );
    sub.add( "History","history" );
    sub.add( "Location","location" );
    sub.add( "Document","document" );
    secciones[c++]=new Seccion( "Window", "js_window.html", sub );
  }
  { //  Objetos de Document
    sub=new many_subseccion;
    sub.add( "getElementById","getElementById" );
    sub.add( "getElementsByTagName","getElementsByTagName" );
    sub.add( "Navegaci�n DOM","navegacion" );
    sub.add( "Acceso atributos","atributos" );
    sub.add( "Modificaci�n contenido","modificacion" );
    sub.add( "Formularios","formularios" );
    secciones[c++]=new Seccion( "Document", "js_document.html", sub );
  }
  { // Cookies
    sub=new many_subseccion;
    sub.add( "Qu� son las cookies","que_son" );
    sub.add( "C�mo se usan","como_se_usan" );
    sub.add( "Ejemplos","ejemplos" );
    secciones[c++]=new Seccion( "Cookies", "js_cookies.html", sub );
  }
  { //  Objetos de Document
    sub=new many_subseccion;
    sub.add( "Instalar GreaseMonkey","greasemonkey" );
    sub.add( "Primer programa", "holaGM");
    sub.add( "A�adir elementos", "aniadir");
    sub.add( "Ficheros externos","externos" );
    secciones[c++]=new Seccion( "GreaseMonkey", "js_greasemonkey.html", sub );
  }
  { //  Apendice
    sub=new many_subseccion;
    sub.add( "Documentaci�n","fuentes" );
    sub.add( "Tutoriales","tutoriales" );
    sub.add( "Juegos","juegos" );
    secciones[c++]=new Seccion( "Ap�ndice", "js_apendice.html", sub );
  }

}

/*
-----------------------------------------------------------
                   OTRAS FUNCIONES Y PROCEDIMIENTOS
-----------------------------------------------------------
*/


/**
* Cabecera: pone la cabecera del curso.
*/
function cabecera_js( seccion ) { 
  var d=document;
  d.writeln("<div class='cabecera'");
  d.writeln("<h3><B>Curso de Javascript</B> ");
  d.writeln("<sub>| Versi�n 2014</sub></h3><br/>");
  d.writeln("<span style='font-size: 80%;'>por V�ctor M. Rivas Santos</span>");
  d.writeln("</div><br/>");
  
  
  // TABLA DE MENU
  secciones[seccion].pinta();

  cuenta_ejemplos=0;
  LA_SECCION=seccion;

};

/**
* Pie: pone el pie del curso.
*/
function pie( ) {
  // TABLA DE MENU
  var d=document;
  d.writeln( "<BR>" );
  d.writeln( "<HR>" );
  d.writeln( '  <TABLE WIDTH="100%" BORDER=0 BGCOLOR=#FFFFFF> ' );
  d.writeln( '    <TR> ' );
  d.writeln( '      <TD ALIGN=left> ' );
  d.writeln( '        <B>V�ctor Manuel Rivas Santos</B><BR> ' );

  d.writeln( '        <FONT SIZE="-1"> ' );

  d.writeln( '          <A HREF="http://wwwdi.ujaen.es">Dpto. de Inform�tica</A><BR> ' );

  d.writeln( '          Area de Lenguajes y Sistemas Inform�ticos<BR> ' );

  d.writeln( '          EPS de Ja�n, Universidad de Ja�n<BR> ' );

 d.writeln( '           Campus Las Lagunillas S/N<BR> ' );

 d.writeln( '           23071, Ja�n (Spain)<BR> ' );

  d.writeln( '      </TD> ' );
  d.writeln( '      <TD ALIGN=right> ' );
  d.writeln( '        Mail: <A HREF="mailto:vrivas@ujaen.es">vrivas@ujaen.es</A><BR><FONT SIZE=-1>' );

  d.writeln( '        Tef: +34 953 21 23 44<BR> ' );

   d.writeln( '       Fax: +34 953 21 24 72<BR> ' );

  d.writeln( '        <HR WIDTH="15%" ALIGN="right"> ' );

  d.writeln( '        Despacho: A3-121<BR> ' );

  d.writeln( '      </TD> ' );
  d.writeln( '    </TR> ' );
 d.writeln( '   </TABLE> ' );
 d.writeln( ' <HR><A HREF="http://vrivas.es"><B>(C) V�ctor M. Rivas Santos</B></A><BR> ');
 d.writeln( '<FONT SIZE=-1><A HREF="http://geneura.wordpress.com">GeNeura Team' );
};


function ejemplo() {
  var d=document;
  cuenta_ejemplos++;
  d.writeln( "<P><U>Ejemplo ",LA_SECCION,".",cuenta_ejemplos,"</U><BR>" );
}

/*
-----------------------------------------------------------
                 LLAMADA PRIMERA A FUNCIONES
-----------------------------------------------------------
*/

inicializa();
